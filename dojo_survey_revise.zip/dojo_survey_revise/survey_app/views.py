from django.shortcuts import render, redirect
LANG = (
    'Python',
    'JavaScript',
    'C#',
    'Java',
    'C'
)
LOC = (
    'Burbank',
    'Chicago',
    'Dallas',
    'Seattle',
    'DC'
)

def index(request):
    context = {
        'location': LOC,
        'language': LANG
    }
    return render(request, 'form.html', context)

def process(request):
    if request.method == 'GET':
        return redirect('/')
    request.session['result'] = {
        'name': request.POST['name'],
        'location': request.POST['location'],
        'language': request.POST['language']
    }
    return redirect('/result')

def result(request):
    context = {
        'result': request.session['result']
    }
    return render(request, 'result.html', context)

# Create your views here.
